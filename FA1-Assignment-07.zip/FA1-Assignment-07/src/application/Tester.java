package application;

import java.util.List;
import java.util.TreeMap;

public class Tester {
	public static void main(String[] args) {
		// Code here
	}
	
	public static TreeMap<Dog, Integer> getDogStatistics(List<Dog> dogList) {
		// Code here
		return null;
	}
}
