DROP TABLE Trainee CASCADE CONSTRAINTS;
DROP TABLE Desktop CASCADE CONSTRAINTS;
DROP SEQUENCE hibernate_sequence;
CREATE SEQUENCE hibernate_sequence START WITH 800003 INCREMENT BY 1;

CREATE TABLE Desktop(
    desktop_id VARCHAR2(15) CONSTRAINT desktop_id_pk PRIMARY KEY,
    desktop_make VARCHAR2(15) CONSTRAINT desktop_make_nnull NOT NULL,
    desktop_model VARCHAR2(10) CONSTRAINT despktop_model_nnull NOT NULL,
    desktop_status VARCHAR2(15) CONSTRAINT despktop_status_nnull NOT NULL
);

CREATE TABLE Trainee(
    trainee_id        NUMBER(7) CONSTRAINT trainee_id_pk PRIMARY KEY,
    trainee_name      VARCHAR2(15) CONSTRAINT trainee_name_nnull NOT NULL,
    desktop_id VARCHAR2(15) CONSTRAINT desktop_id_unique UNIQUE CONSTRAINT trainee_FK REFERENCES Desktop(desktop_id)
);

INSERT INTO Desktop VALUES('MYSGEC111111D','Acer','Aspire','ALLOCATED');
INSERT INTO Desktop VALUES('MYSGEC222222D','Dell','Vostro','AVAILABLE');

INSERT INTO Trainee VALUES(800001,'Scott','MYSGEC111111D');
INSERT INTO Trainee VALUES(800002,'Jack',null);


COMMIT;

SELECT * FROM Desktop;
SELECT * FROM Trainee;
