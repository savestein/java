package com.infy.entity;

public class DesktopEntity {
		
}
