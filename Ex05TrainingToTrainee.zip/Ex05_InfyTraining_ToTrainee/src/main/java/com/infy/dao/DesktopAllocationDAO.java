package com.infy.dao;


import com.infy.model.Desktop;
import com.infy.model.Trainee;

public interface DesktopAllocationDAO {

	public Trainee getTraineeDetails(Integer traineeId) throws Exception;

	public Integer addTrainee(Trainee trainee) throws Exception;

	public Integer allocateDesktop(Integer traineeId, String desktopId) throws Exception;

	public Integer deallocateDesktop(Integer traineeId) throws Exception;

	public void deleteTrainee(Integer traineeId) throws Exception;
	
	public Desktop getDesktopDetails(String desktopId) throws Exception;

}
