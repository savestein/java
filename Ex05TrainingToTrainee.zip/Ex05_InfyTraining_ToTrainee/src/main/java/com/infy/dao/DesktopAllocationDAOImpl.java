package com.infy.dao;

import com.infy.model.Desktop;
import com.infy.model.Trainee;


public class DesktopAllocationDAOImpl implements DesktopAllocationDAO {

	@Override
	public Trainee getTraineeDetails(Integer traineeId) throws Exception {
		return null;
	}
	
	@Override
	public Desktop getDesktopDetails(String desktopId) throws Exception {
		return null;
		
	}

	@Override
	public Integer addTrainee(Trainee trainee) throws Exception {
		return null;

	}
	
	@Override
	public Integer allocateDesktop(Integer traineeId, String desktopId) throws Exception {
		return null;
	}
	
	@Override
	public Integer deallocateDesktop(Integer traineeId) throws Exception {
		return null;

	}

	@Override
	public void deleteTrainee(Integer traineeId) throws Exception {

	}

}
