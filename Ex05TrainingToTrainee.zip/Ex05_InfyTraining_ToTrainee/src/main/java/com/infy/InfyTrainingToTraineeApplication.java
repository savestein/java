package com.infy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.model.Desktop;
import com.infy.model.Trainee;
import com.infy.service.DesktopAllocationService;

@SpringBootApplication
public class InfyTrainingToTraineeApplication implements CommandLineRunner {

	@Autowired
	DesktopAllocationService service;
	
	@Autowired
	Environment environment;

	public static void main(String[] args) {
		SpringApplication.run(InfyTrainingToTraineeApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		addTrainee();
		//getTraineeDetails();
		//getDesktopDetails();

		 

		// allocateDesktop();

		// deallocateDesktop();

		// deleteTrainee();

	}

	void getTraineeDetails() {
		try {
			Integer traineeId = 800001;

			Trainee trainee = service.getTraineeDetails(traineeId);

			System.out.println("Trainee and Desktop details");
			System.out.println("-----------------------------------------");
			System.out.println("Trainee id \t\t:" + trainee.getTraineeId());
			System.out.println("Trainee name \t\t:" + trainee.getTraineeName());
			if (trainee.getDesktop() == null) {
				System.out.println("No desktop is available");
			}
			if (trainee.getDesktop() != null) {
				System.out.println("Desktop id \t\t:" + trainee.getDesktop().getDesktopId());
				System.out.println("Desktop make \t\t:" + trainee.getDesktop().getDesktopMake());
				System.out.println("Desktop model \t\t:" + trainee.getDesktop().getDesktopModel());
			}
		} catch (Exception e) {
			System.out.println(
					environment.getProperty(e.getMessage(), "Some exception occureed. Please check log file."));

		}
	}

	void getDesktopDetails() {
		try {
			String desktopId = "MYSGEC111111D";

			Desktop desktop = service.getDesktopDetails(desktopId);

			System.out.println("Desktop details");
			System.out.println("-----------------------------------------");
			System.out.println("Desktop id \t\t:" + desktop.getDesktopId());
			System.out.println("Desktop make \t\t:" + desktop.getDesktopMake());
			System.out.println("Desktop model \t\t:" + desktop.getDesktopModel());
			System.out.println("Desktop status \t\t:" + desktop.getDesktopStatus());

		} catch (Exception e) {
			System.out.println(
					environment.getProperty(e.getMessage(), "Some exception occureed. Please check log file."));

		}
	}

	void addTrainee() {
		try {
			Trainee trainee = new Trainee();
			trainee.setTraineeName("John");

			Integer traineeId = service.addTrainee(trainee);

			String message = environment.getProperty("UserInterface.TRAINEE_SUCCESS");
			System.out.println(message + traineeId);
		} catch (Exception e) {
			System.out.println(
					environment.getProperty(e.getMessage(), "Some exception occureed. Please check log file."));

		}
	}

	void allocateDesktop() {
		try {
			String desktopId = "MYSGEC222222D";
			Integer traineeId = 800002;

			service.allocateDesktop(traineeId, desktopId);
			System.out.println(environment.getProperty("UserInterface.DESKTOP_ALLOCATED_SUCCESS"));

		} catch (Exception e) {
			System.out.println(
					environment.getProperty(e.getMessage(), "Some exception occureed. Please check log file."));

		}
	}

	void deallocateDesktop() {
		try {

			Integer traineeId = 800001;

			service.deallocateDesktop(traineeId);
			System.out.println(environment.getProperty("UserInterface.DESKTOP_DEALLOCATED_SUCCESS"));

		} catch (Exception e) {
			System.out.println(
					environment.getProperty(e.getMessage(), "Some exception occureed. Please check log file."));

		}
	}

	void deleteTrainee() {
		try {

			Integer traineeId = 800001;

			service.deleteTrainee(traineeId);
			System.out.println(environment.getProperty("UserInterface.TRAINEE_DELETED_SUCCESS"));

		} catch (Exception e) {
			System.out.println(
					environment.getProperty(e.getMessage(), "Some exception occureed. Please check log file."));

		}
	}
}
