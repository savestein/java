package com.infy.service;


import com.infy.model.Desktop;

import com.infy.model.Trainee;


public class DesktopAllocationServiceImpl implements DesktopAllocationService {

	
	@Override
	public Trainee getTraineeDetails(Integer traineeId) throws Exception {
		return null;
	}
	
	@Override
	public Desktop getDesktopDetails(String despktopId) throws Exception {
		return null;
	}

	@Override
	public Integer addTrainee(Trainee trainee) throws Exception {
		return null;

	}

	@Override
	public void allocateDesktop(Integer traineeId, String desktopId) throws Exception {

	}
	
	@Override
	public void deallocateDesktop(Integer traineeId) throws Exception {

	}
	
	@Override
	public void deleteTrainee(Integer traineeId) throws Exception {
		
	}
	
}
