package com.infy.service;

import com.infy.model.Desktop;
import com.infy.model.Trainee;

public interface DesktopAllocationService {

	public Trainee getTraineeDetails(Integer traineeId) throws Exception;

	public Integer addTrainee(Trainee trainee) throws Exception;

	public void allocateDesktop(Integer traineeId, String desktopId) throws Exception;

	public void deallocateDesktop(Integer traineeId) throws Exception;

	public void deleteTrainee(Integer traineeId) throws Exception;
	
	public Desktop getDesktopDetails(String desktopId) throws Exception;
}
