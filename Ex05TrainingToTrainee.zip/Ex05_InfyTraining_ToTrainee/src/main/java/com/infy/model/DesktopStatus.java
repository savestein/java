package com.infy.model;

public enum DesktopStatus {
	AVAILABLE,ALLOCATED;
}
